/**
 *
 * Copyright (C), 2014-2014, HAOHAN DATA Technology Co., Ltd.
 *
 * @file hos_cmd.h
 *
 * @brief hos_cmd.h header file
 *
 * @author clx@haohandata.com.cn
 * @date 2015/6/5
 *
 * @note
 *    Function List :
 *    History :
 *	    1.Date : 2015/6/5
 *	      Author : clx@haohandata.com.cn
 *	      Modification : Created file
 *
 */
#ifndef __HOS_CMD_H__
#define __HOS_CMD_H__


#define CMD_NEWLINE ("\r\n")


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

    int CMDInit();
    int CMDStart();
    int CMDAddNode(const char *ParentName, const char *Name, const char *Desc, void *SaveFun);
    int CMDAddCmd(const char *ParentName, const char *CmdSpec, const char *Desc, void *Fun);
    int CMDPrint(char *fmt, ...);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __HOS_CMD_H__ */











