#include <pthread.h>
#include "zebra.h"
#include "command.h"
#include <dlfcn.h>  
#include "mod_export.h"
#include <sys/prctl.h> 
#include "vty.h"
#include "memory.h"
#include "buffer.h"
/* Default port information. */
#define ZEBRA_VTY_PORT                23
/* Default configuration filename. */
#define DEFAULT_CONFIG_FILE "/hs/conf/csh.conf"

/* Default configuration file path. */
char config_default[128] = DEFAULT_CONFIG_FILE;
struct thread_master *master_tmp;
struct thread thread;
static int read_conf_ok = 0;

static int HOS_CMD_Node_Enable 
    (struct cmd_element *self , 
     struct vty *vty , 
     int argc , 
     const char *argv[] )
{

    vty->node = self->node;
    
    return CMD_SUCCESS;
}

HOS_CMD_CFG_S g_HOS_CMD_CFG = 
{
    .CurNodeId = CUSTOM_NODE,
    
};

void *HOS_CMD_MallocZero(unsigned int num_bytes)
{
        void *M =malloc(num_bytes);
        if (M) {
            memset(M,0,num_bytes);
        }
        return M;
}

SDPI_API int
CMDInit()
{
    umask (0027);

    /* Make master thread emulator. */
    master_tmp = thread_master_create ();

    vty_cmd_init (1);

    return 0;
}

SDPI_API int
CMDAddNode(char *ParentName, char *Name, char *Desc, void *SaveFun)
{
    unsigned int        ParentNodeId = 0;
    struct cmd_node    *NodeTmp      = NULL;
    HOS_CMD_LIST_S     *HeadTmp      = NULL;
    struct cmd_element *EleMent      = NULL;

    if (ParentName == NULL || Name == NULL)
    {
        return -1;
    }
    
    NodeTmp         = (struct cmd_node*)HOS_CMD_MallocZero(sizeof(struct cmd_node));
    NodeTmp->node   = g_HOS_CMD_CFG.CurNodeId;
    NodeTmp->prompt = (char*)HOS_CMD_MallocZero(strlen(Name)+4);
    sprintf((char*)NodeTmp->prompt ,"%%s.%s#",Name);

    HeadTmp            = (HOS_CMD_LIST_S*)HOS_CMD_MallocZero(sizeof(HOS_CMD_LIST_S));
    HeadTmp->Node      = NodeTmp;
    HeadTmp->Next      = g_HOS_CMD_CFG.Head;
    g_HOS_CMD_CFG.Head = HeadTmp;
    
    if (strncmp("root", ParentName, sizeof("root") - 1) == 0)
    {
        ParentNodeId = VIEW_NODE;
        HeadTmp      = NULL;
    }
    else
    {
        HeadTmp      = g_HOS_CMD_CFG.Head;
        ParentNodeId = 0;
    }
    
    while (HeadTmp != NULL)
    {
        if(strncmp(HeadTmp->Node->prompt+3,ParentName,strlen(ParentName)) == 0)
        {
            ParentNodeId = HeadTmp->Node->node;
            break;
        }
        HeadTmp = HeadTmp->Next;
    }
    if(ParentNodeId == 0)
    {
        return -1;
    }

    install_node_parent(NodeTmp, SaveFun, ParentNodeId);
    
    EleMent = (struct cmd_element *)HOS_CMD_MallocZero(sizeof(struct cmd_element));
    EleMent->string = (char*)HOS_CMD_MallocZero(strlen(Name));
    sprintf((char*)EleMent->string ,"%s",Name);
    EleMent->doc = (char*)HOS_CMD_MallocZero(strlen(Desc)+4);
    strcpy((char*)EleMent->doc,Desc);

    EleMent->node = g_HOS_CMD_CFG.CurNodeId;  
    EleMent->func = HOS_CMD_Node_Enable;

    install_element(ParentNodeId, EleMent);
    install_default(g_HOS_CMD_CFG.CurNodeId);
    g_HOS_CMD_CFG.CurNodeId++;
    
    return 0;
}

int
CMDAddCmd2(char *ParentName, char *CmdSpec, char *Desc, void *Fun)
{
    unsigned int ParentNodeId = 0; /*���ڵ�id*/
    HOS_CMD_LIST_S *HeadTmp = NULL;
    struct cmd_element *EleMent = NULL;

    if (ParentName == NULL || CmdSpec == NULL || Fun == NULL)
    {
        return -1;
    }
    
    if(strncmp("root",ParentName,sizeof("root") - 1) == 0)
    {
        ParentNodeId = VIEW_NODE;
        HeadTmp = NULL;
    }
    else
    {
        HeadTmp = g_HOS_CMD_CFG.Head;
        ParentNodeId = 0;
    }
    while(HeadTmp!= NULL)
    {
        if(strncmp(HeadTmp->Node->prompt+3,ParentName,strlen(ParentName)) == 0)
        {
            ParentNodeId = HeadTmp->Node->node;
            break;
        }
        HeadTmp = HeadTmp->Next;
    }
    if(ParentNodeId == 0)
    {
        return -1;
    }
    
    EleMent = (struct cmd_element *)HOS_CMD_MallocZero(sizeof(struct cmd_element ));
    EleMent->string = (char*)HOS_CMD_MallocZero(strlen(CmdSpec) + 1);
    sprintf((char*)EleMent->string ,"%s",CmdSpec);
    EleMent->doc = (char*)HOS_CMD_MallocZero(strlen(Desc)+4);
    strcpy((char*)EleMent->doc,Desc);
    EleMent->node = ParentNodeId;  
    EleMent->func_element = Fun;

    install_element(ParentNodeId, EleMent);

    return 0;
}

SDPI_API int
CMDAddCmd(char *ParentName, char *CmdSpec, char *Desc, void *Fun)
{
    char spec[4096];
    char desc[4096];

    snprintf(spec, sizeof(spec), "%s %s", ParentName, CmdSpec);
    snprintf(desc, sizeof(spec), "%s\r\n%s", ParentName, Desc);

    if (CMDAddCmd2("root", spec, desc, Fun) != 0) {
        return -1;
    }
    if (CMDAddCmd2(ParentName, CmdSpec, Desc, Fun) != 0) {
        return -1;
    }

    return 0;
}

int CMDStartInner()
{
    /* struct thread thread; */
    prctl(PR_SET_NAME, "rubicon_cmd");  
    vty_init(master_tmp);
#if 0 //���߳�����
    //���� SIGPIPE
    sigset_t signal_mask;
    sigemptyset (&signal_mask);
    sigaddset (&signal_mask, SIGPIPE);
    pthread_sigmask (SIG_BLOCK, &signal_mask, NULL);
#endif
    vty_read_config(NULL, DEFAULT_CONFIG_FILE); 

    /* Make vty server socket. */
    vty_serv_sock (NULL, ZEBRA_VTY_PORT, ZEBRA_VTYSH_PATH);
    read_conf_ok = 1;

    while(thread_fetch (master_tmp, &thread))
        thread_call (&thread);

    /* Not reached... */
    return 0;
}

SDPI_API int
CMDStart()
{
    int       ret;
    pthread_t tid;
    
    ret = pthread_create(&tid, NULL, (void *)CMDStartInner, NULL);

    /* �������ж�ȡ��Ĭ�ϵ����ã��ٷ��ء��������Ա�֤�ڵõ���ȷ������֮ǰ��ת���� */
    while (read_conf_ok != 1) {
        sleep(1);
    }

    return ret;
}
#if 0
/* ע�⣬���б�����\r\n */
SDPI_API int
CMDPrint(char *fmt, ...)
{
    int         n;
    va_list     argptr;
    char        buf[2048];
    struct vty *vty = THREAD_ARG(&thread);

    if(NULL == vty)
    {
        return 0;
    }

    bzero(buf, sizeof(buf));
    va_start(argptr, fmt);
    n = vsprintf(buf, fmt, argptr);
    va_end(argptr);

    vty_out(vty, buf);

    return n;
}
#endif
SDPI_API int
CMDPrint(const char *format, ...)
{
    struct vty *vty = THREAD_ARG(&thread);
    va_list args;
    int len = 0;
    int size = 1024;
    char buf[1024];
    char *p = NULL;
    if(NULL == vty)
    {
        return 0;
    }

    if (vty_shell (vty))
    {
        va_start (args, format);
        vprintf (format, args);
        va_end (args);
    }
    else
    {
        /* Try to write to initial buffer.  */
        va_start (args, format);
        len = vsnprintf (buf, sizeof buf, format, args);
        va_end (args);

        /* Initial buffer is not enough.  */
        if (len < 0 || len >= size)
        {
            while (1)
            {
                if (len > -1)
                    size = len + 1;
                else
                    size = size * 2;

                p = XREALLOC (MTYPE_VTY_OUT_BUF, p, size);
                if (! p) {
                    buffer_put(vty->obuf, "OUT PUT ERROR!", 14);
                    return -1;
                }

                va_start (args, format);
                len = vsnprintf (p, size, format, args);
                va_end (args);

                if (len > -1 && len < size)
                    break;
            }
        }

        /* When initial buffer is enough to store all output.  */
        if (! p)
            p = buf;

        /* Pointer p must point out buffer. */
        buffer_put (vty->obuf, (u_char *) p, len);

        /* If p is not different with buf, it is allocated buffer.  */
        if (p != buf)
            XFREE (MTYPE_VTY_OUT_BUF, p);
    }

    return len;
}

