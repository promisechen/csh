#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdint.h>
#include "../hs_cmd.h"

int CmdInterfaceSave(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    int BufMaxLen = 1024;
    
    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);
    
    sprintf(*Buf,
            "! interface save\r\n"
            "policy add ip 2.1.1.1/24 type CLASS id 2 block\r\n"
            "policy add ip 2.1.1.1/24 type CLASS id 2 block\r\n");
    *BufLen = BufMaxLen;

    return 0;
}

int CmdPolicySave(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    int BufMaxLen = 1024;
    
    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);
    
    sprintf(*Buf,
            "! policy save\r\n"
            "policy add ip 1.1.1.1/24 type CLASS id 1 block\r\n"
            "policy add ip 1.1.1.1/24 type CLASS id 1 block\r\n");
    *BufLen = BufMaxLen;

    return 0;
}
    
int CmdPolicyAdd(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    int i;
    int BufMaxLen = 1024;
    int ilen      = 0;

    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);

    ilen += snprintf(*Buf + ilen, BufMaxLen - ilen, "Buf: %0x, BufLen: %d\r\n", *Buf, BufLen);
    ilen += snprintf(*Buf + ilen, BufMaxLen - ilen, "argc=%d\r\n", Argc);
    for (i = 0; i < Argc; i++ )
    {
        ilen += snprintf (*Buf + ilen, BufMaxLen - ilen, "argv[%d]=%s\r\n", i, Argv[i]);
    }
    *BufLen = BufMaxLen;
    
    return 0;
}

int mac_str_to_bin(char *str, uint8_t *mac)
{
    int i;
    char *s, *e;

    if ((mac == NULL) || (str == NULL))
    {
        return -1;
    }

    s = (char *)str;
    for (i = 0; i < 6; ++i)
    {
        mac[i] = s ? strtoul(s, &e, 16) : 0;
        if (s) {
            s = (*e) ? e + 1 : e;
        }
    }
    return 0;
}

/* 
 * argc=2
 * argv[0]=3
 * argv[1]=11:22:33:44:55:66
 */
int CmdSetMac(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    int BufMaxLen = 1024;

    if (Argc != 2)
    {
        return -1;
    }

    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);
    *BufLen = BufMaxLen;
    
    /* 解析mac地址。如果出错。回显错误 */
    uint8_t dst_mac[6];
    if (mac_str_to_bin(Argv[1], dst_mac) == -1)
    {
        snprintf(*Buf, BufMaxLen, "MAC address error\r\n");
        return 0;
    }

    uint8_t channel_id;
    channel_id = atoi(Argv[0]);
    
    /* 设置mac封装 */
    
    /* 回显 */
    snprintf(*Buf,
             BufMaxLen,
             "set channel %d mac encapsulation. dst MAC address: %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\r\n",
             channel_id,
             dst_mac[0], dst_mac[1], dst_mac[2], dst_mac[3], dst_mac[4], dst_mac[5]);
    
    return 0;
}

int CmdSetGre(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    int i;
    int BufMaxLen = 1024;
    int ilen      = 0;

    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);

    ilen += snprintf(*Buf + ilen, BufMaxLen - ilen, "Buf: %0x, BufLen: %d\r\n", *Buf, BufLen);
    ilen += snprintf(*Buf + ilen, BufMaxLen - ilen, "argc=%d\r\n", Argc);
    for (i = 0; i < Argc; i++ )
    {
        ilen += snprintf (*Buf + ilen, BufMaxLen - ilen, "argv[%d]=%s\r\n", i, Argv[i]);
    }
    *BufLen = BufMaxLen;
    
    return 0;
}

int CmdPolicyShow(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    /* 
     * int i;
     * int ilen      = 0;
     * int BufMaxLen = 4096;
     * 
     * *Buf = (char *)malloc(BufMaxLen);
     * memset(*Buf, 0, BufMaxLen);
     * 
     * for (i = 0; i < 40; i++)
     * {
     *     ilen += snprintf (*Buf + ilen, BufMaxLen - ilen, "a");
     * }
     * 
     * sprintf(*Buf + ilen, "policy show\r\n");
     * 
     * *BufLen = BufMaxLen;
     */

    int a = 2;
    CMDPrint("1234a%d5\r\n", a);
    CMDPrint("asdasdfasd dddddddddd new line%s", CMD_NEWLINE);

    return 0;
}

int CmdPolicyBlock(int Argc, char *Argv[], char **Buf, int *BufLen)
{
    if (Argc != 1)
    {
        return -1;
    }

    int BufMaxLen = 128;
    *Buf = (char *)malloc(BufMaxLen);
    memset(*Buf, 0, BufMaxLen);
    
    if (strncmp(Argv[0], "yes", sizeof("yes")) == 0)
    {
        /* set send rst */
        sprintf(*Buf, "block set send rst packet yes.\r\n");
    }
    else
    {
        /* set not send rst */
        sprintf(*Buf, "block set send rst packet no.\r\n");
    }
    *BufLen = BufMaxLen;
    
    return 0;
}

main()
{
    CMDInit();

    CMDAddNode("root", "dpi", "dpi desc", CmdPolicySave);
    CMDAddNode("root", "dpi2", "dpi2 desc", CmdPolicySave);
    CMDAddNode("root", "interface", "interface desc", CmdInterfaceSave);

    CMDAddCmd("dpi",
              "policy add ip A.B.C.D/M type (class|subclass|patton) id <0-8192> block",
              "policy desc\nadd policy", CmdPolicyAdd);
    CMDAddCmd("dpi",
              "policy show",
              "policy desc\nshow policy", CmdPolicyShow);

    /* 可选项命令定义 route-map3 .aa 可变变量指的是变量参数的个数可变 */
    CMDAddCmd("dpi",
              "policy option {metric <0-16777214>|metric-type (1|2)|route-map WORD|route-map2 [aaa]|route-map3 .aa}",
              "policy desc\noption desc", CmdPolicyAdd);

    /* block set cmd */
    CMDAddCmd("dpi",
              "config block_send_rst (yes|no)",
              "block tcp link, send or not send rst packet",
              CmdPolicyBlock);

    /* mirror set cmd */
    CMDAddCmd("dpi",
              "mirror gre encapsulation channel id <0-8> srcip A.B.C.D dstip A.B.C.D srcmac MAC dstmac MACC",
              "mirror configure\n gre encapsulation",
              CmdSetGre);

    CMDAddCmd("dpi",
              "mirror mac encapsulation channel id <0-8> dstmac MAC",
              "mirror configure\nmac encapsulation",
              CmdSetMac);

    /* dpi2 节点内部命令 */
    CMDAddCmd("dpi2",
              "config block_send_rst (yes|no)",
              "block tcp link, send or not send rst packet",
              CmdPolicyBlock);

    CMDStart();

    sleep(9999999);
}

